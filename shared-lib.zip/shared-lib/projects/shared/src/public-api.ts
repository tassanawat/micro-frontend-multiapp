/*
 * Public API Surface of shared
 */

export * from './lib/shared.service';
export * from './lib/shared.component';
export * from './lib/shared.module';
